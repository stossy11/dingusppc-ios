//
//  dingusppc-ios-bridging-header.h
//  dingusppc-ios
//
//  Created by Stossy11 on 07/01/2025.
//

#ifdef __cplusplus
extern "C" {
#endif

#include "main.cpp"


#ifdef __cplusplus
}
#endif

