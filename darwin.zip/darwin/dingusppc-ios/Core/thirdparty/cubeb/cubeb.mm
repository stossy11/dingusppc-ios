//
//  cubeb.mm
//  dingusppc-ios
//
//  Created by Stossy11 on 07/01/2025.
//

#import <Foundation/Foundation.h>
#include "cubeb.h"

#pragma mark - CUBEB Implementation

/** Opaque handle referencing the application state. */
typedef struct cubeb {
    NSString *contextName;
} cubeb;

/** Opaque handle referencing the stream state. */
typedef struct cubeb_stream {
    NSString *streamName;
    cubeb_stream_params params;
    unsigned int latency;
    cubeb_data_callback dataCallback;
    cubeb_state_callback stateCallback;
    void *userPointer;
    BOOL isPlaying;
    uint64_t position;
} cubeb_stream;

int cubeb_init(cubeb **context, char const *context_name) {
    if (!context) return CUBEB_ERROR;
    *context = (cubeb *)malloc(sizeof(cubeb));
    if (!*context) return CUBEB_ERROR;
    (*context)->contextName = [NSString stringWithUTF8String:context_name ?: "Unknown Context"];
    return CUBEB_OK;
}

char const *cubeb_get_backend_id(cubeb *context) {
    return "simple_backend";
}

void cubeb_destroy(cubeb *context) {
    if (context) {
        free(context);
    }
}

int cubeb_get_min_latency(cubeb *context, cubeb_stream_params params, unsigned int *latency) {
    if (!context || !latency) {
        return CUBEB_ERROR;
    }
    // Stubbed to return a fixed minimum latency for simplicity
    *latency = 50; // 50ms
    return CUBEB_OK;
}

int cubeb_stream_init(cubeb *context,
                      cubeb_stream **stream,
                      char const *stream_name,
                      cubeb_stream_params stream_params,
                      unsigned int latency,
                      cubeb_data_callback data_callback,
                      cubeb_state_callback state_callback,
                      void *user_ptr) {
    if (!context || !stream || !data_callback || latency < 1 || latency > 2000) {
        return CUBEB_ERROR;
    }

    unsigned int min_latency;
    if (cubeb_get_min_latency(context, stream_params, &min_latency) != CUBEB_OK || latency < min_latency) {
        return CUBEB_ERROR_INVALID_FORMAT;
    }

    *stream = (cubeb_stream *)malloc(sizeof(cubeb_stream));
    if (!*stream) return CUBEB_ERROR;

    (*stream)->streamName = [NSString stringWithUTF8String:stream_name ?: "Unknown Stream"];
    (*stream)->params = stream_params;
    (*stream)->latency = latency;
    (*stream)->dataCallback = data_callback;
    (*stream)->stateCallback = state_callback;
    (*stream)->userPointer = user_ptr;
    (*stream)->isPlaying = NO;
    (*stream)->position = 0;

    return CUBEB_OK;
}

void cubeb_stream_destroy(cubeb_stream *stream) {
    if (stream) {
        free(stream);
    }
}

int cubeb_stream_start(cubeb_stream *stream) {
    if (!stream || stream->isPlaying) return CUBEB_ERROR;
    stream->isPlaying = YES;
    if (stream->stateCallback) {
        stream->stateCallback(stream, stream->userPointer, CUBEB_STATE_STARTED);
    }
    return CUBEB_OK;
}

int cubeb_stream_stop(cubeb_stream *stream) {
    if (!stream || !stream->isPlaying) return CUBEB_ERROR;
    stream->isPlaying = NO;
    if (stream->stateCallback) {
        stream->stateCallback(stream, stream->userPointer, CUBEB_STATE_STOPPED);
    }
    return CUBEB_OK;
}

int cubeb_stream_get_position(cubeb_stream *stream, uint64_t *position) {
    if (!stream || !position) return CUBEB_ERROR;
    *position = stream->position;
    return CUBEB_OK;
}
