//
//  dingusppc_iosApp.swift
//  dingusppc-ios
//
//  Created by Stossy11 on 07/01/2025.
//

import SwiftUI

@main
struct dingusppc_iosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
